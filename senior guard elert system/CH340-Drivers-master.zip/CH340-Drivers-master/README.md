# CH340-Drivers
CH340 Drivers for Hobby Components Products

####Microsoft Windows:
Windows drivers support 32 and 64 bit versions of the opperating system. These drivers will need to be installed whn using any of the Hobby Components products listed below.

####Linux drivers:
Most popular versions will include a sutable driver and so no additional installation is normally required.



**PLEASE NOTE: We have made this driver available on GitHub for easy access by our customers. If you are a Hobby Components customer and are experiencing issues installing this driver please contact us either via our support forum (https://forum.hobbycomponents.com) or directly via our contact page (https://hobbycomponents.com/contact-us). **

**WE CANNOT provide technical support to non-customers. If you did not purchase your item from Hobby Components and are experiencing issues then we advise contacting the vendor  that you bought the item from.**




###Supported products:


**Hobby Components Arduino Compatible Uno+ (HCARDU0100)**

![alt tag](http://hobbycomponents.com/images/forum/HCARDU0100_1_800_600.JPG)

http://hobbycomponents.com/boards/670-hobby-components-uno-plus


**Hobby Components Arduino Compatible Nano with CH340 (HCARDU0094)**

![alt tag](http://hobbycomponents.com/images/forum/HCARDU0094_800_600.JPG)

http://hobbycomponents.com/featured/98-arduino-compatible-nano-v30-with-free-usb-cable


**CH340 USB to TTL Serial Adaptor (HCMODU0076)**

![alt tag](http://hobbycomponents.com/images/forum/HCMODU0076_800_600.JPG)

http://hobbycomponents.com/home/586-ch340-usb-to-ttl-serial-adaptor
